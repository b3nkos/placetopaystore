---
name: 🐞 Bug Fix
about: You have a fix for a bug?
labels: bug
---

<!--
- Please do not send a pull request for an issue in a version of PHPUnit that is no longer supported. A list of currently supported versions of PHPUnit is available at https://phpunit.de/supported-versions.html.
- Please target the oldest branch of PHPUnit that is affected by this bug and is still supported. A list of currently supported versions of PHPUnit is available at https://phpunit.de/supported-versions.html.
-->
